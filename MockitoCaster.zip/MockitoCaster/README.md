# Mockito
Example project used in the Caster.io course on Mockito and clean unit testing

View the course at https://caster.io/courses/mockito/
