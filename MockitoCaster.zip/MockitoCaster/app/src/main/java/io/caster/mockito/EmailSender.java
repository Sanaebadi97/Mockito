package io.caster.mockito;

public interface EmailSender {

    boolean sendRegistrationEmail(RegistrationEmail email);

}
