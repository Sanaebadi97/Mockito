package io.caster.mockito;

public class UserAlreadyRegisteredException extends Throwable {
}
