package io.caster.mockito;

import java.io.IOException;

public class EmailFailedException extends IOException {
}
