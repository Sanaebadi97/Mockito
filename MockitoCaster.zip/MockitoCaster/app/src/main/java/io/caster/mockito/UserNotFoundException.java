package io.caster.mockito;

public class UserNotFoundException extends Throwable {
}
